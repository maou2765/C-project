#include "Vehicle.h"
class DeliveryCar: protected Vehicle{
    public:
        DeliveryCar(int nc, Color color,int mileage,int charge);
        void setChargePerMile(int);
        int getCharge() const;
        void start();
        void brake(int);
        void print() const;
        ~DeliveryCar();
    private:
        int chargePerMile;
};
