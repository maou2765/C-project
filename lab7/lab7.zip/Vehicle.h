#include "Engine.h"
#ifndef VEHICLE_H_
#define VEHICLE_H_
class Vehicle : private Engine
{
    public:
        Vehicle(int nc,Color color,int mileage);
        Color getColor()const;
        int getMileage() const;
        int getEngine() const;
        void start();
        void brake(int dist);
        void print() const;
        ~Vehicle();
    private:
        Color color;
        int mileage;
};
#endif
