#include "Vehicle.h"
Vehicle::Vehicle(int nc,Color color,int mileage):Engine(nc),color(color),mileage(mileage){}
Color Vehicle::getColor() const{
    return color;
}
int Vehicle::getMileage() const{
    return mileage;
}
int Vehicle::getEngine() const{
    return Engine::getNumCylinder();
}
void Vehicle::start(){
    cout<<"Car with ";
    Engine::Start();
}
void Vehicle::brake(int dist){
    cout<<"Car with ";
    Engine::Stop();
    mileage+=dist;
    cout<<"Driving distance: "<<dist<<endl;
}
void Vehicle::print() const{
    string temp[]={"Black", "White", "Sliver", "Grey", "Red", "Blue"};
    cout<<"Engine:"<<Engine::getNumCylinder()<<'\t'<<"Color: "<<temp[color]<<'\t'<<"Current Mileage: "<<mileage<<endl;
}
Vehicle::~Vehicle(){
    cout<<"Calling Vehicle's destructor on the following vehicle:"<<endl;
    print();
    cout<<endl;
}
