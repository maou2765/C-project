#include "PoliceCar.h"
PoliceCar::PoliceCar(int nc, Color c,int m, bool action):Car(nc,c,m),inAction(action){}
bool PoliceCar::getInAction()const{
    return inAction;
}
void PoliceCar::setInAction(bool action) {
    inAction=action;
}

void PoliceCar::print()const{
    cout<<"Information of the police car:"<<endl;
    Car::print();
    if(not inAction){
        cout<<"State: not in action"<<endl;
    }else{
        cout<<"State: in action"<<endl;
    }
}
PoliceCar::~PoliceCar(){
    cout<<"Calling PoliceCar's destructor on the following police car:"<<endl;
    print();
    cout<<endl;
}
