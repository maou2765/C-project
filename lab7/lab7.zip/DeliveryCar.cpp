#include"DeliveryCar.h"
DeliveryCar::DeliveryCar(int nc, Color color, int mileage,int charge):Vehicle(nc,color,mileage),chargePerMile(charge){}

int DeliveryCar::getCharge()const{
    return chargePerMile;
}
void DeliveryCar::setChargePerMile(int charge){
    chargePerMile=charge;
}
void DeliveryCar::start(){
    Vehicle::start();
}
void DeliveryCar::brake(int mile){
    Vehicle::brake(mile);
}
void DeliveryCar::print()const{
    cout<<"Information of the delivery car:"<<endl;
    Vehicle::print();
    cout<<"Charges per mile: "<<chargePerMile<<endl;
    cout<<"Calculated charges:"<<chargePerMile*Vehicle::getMileage()<<endl;
}
DeliveryCar::~DeliveryCar(){
    cout<<"Calling Vehicle's destructor on the following delivery car:"<<endl;
    print();
    cout<<endl;
}
